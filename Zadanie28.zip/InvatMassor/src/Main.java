import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("40 задач по рекурсии (Java)");
        System.out.print("Введите номер задачи (1-40): ");
        int task = readInt();
        try {
            runTask(task);
        } catch (StackOverflowError e) {
            System.out.println("Слишком большой ввод для рекурсивного решения.");
        } catch (IllegalArgumentException | ArithmeticException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    static int readInt() {
        while (!sc.hasNextInt()) { sc.next(); System.out.print("Введите целое число: "); }
        return sc.nextInt();
    }
    static int[] readArray() {
        System.out.print("Количество элементов: ");
        int n = readInt();
        if (n < 0 || n > 10000) throw new IllegalArgumentException("размер массива должен быть от 0 до 10000");
        int[] a = new int[n];
        System.out.println("Введите " + n + " целых чисел:");
        for (int i = 0; i < n; i++) a[i] = readInt();
        return a;
    }
    static String readLinePrompt(String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }
    static void runTask(int t) {
        switch (t) {
            case 1: { System.out.print("N = "); int n=readInt(); printUp(n); System.out.println(); break; }
            case 2: { System.out.print("N = "); int n=readInt(); printDown(n); System.out.println(); break; }
            case 3: { System.out.print("N = "); int n=readInt(); System.out.println("Сумма = "+sumN(n)); break; }
            case 4: { System.out.print("N (0..20) = "); int n=readInt(); if(n<0||n>20) throw new IllegalArgumentException("для long используйте N от 0 до 20"); System.out.println("Факториал = "+factorial(n)); break; }
            case 5: { System.out.print("a = "); int a=readInt(); System.out.print("n (>=0) = "); int n=readInt(); System.out.println("Результат = "+power(a,n)); break; }
            case 6: { System.out.print("Натуральное число = "); int n=readInt(); System.out.println("Сумма цифр = "+digitSum(Math.abs(n))); break; }
            case 7: { System.out.print("Неотрицательное число = "); int n=readInt(); if(n<0) throw new IllegalArgumentException("число должно быть неотрицательным"); System.out.println("Количество цифр = "+digitCount(n)); break; }
            case 8: { System.out.print("Натуральное число = "); int n=readInt(); System.out.println("Произведение цифр = "+digitProduct(Math.abs(n))); break; }
            case 9: { System.out.print("Натуральное число = "); int n=readInt(); System.out.println("Максимальная цифра = "+maxDigit(Math.abs(n))); break; }
            case 10:{ System.out.print("Натуральное число = "); int n=readInt(); System.out.println("Минимальная цифра = "+minDigit(Math.abs(n))); break; }
            case 11:{ System.out.print("N (0..45) = "); int n=readInt(); if(n<0||n>45) throw new IllegalArgumentException("N должно быть от 0 до 45"); System.out.println("F("+n+") = "+fib(n)); break; }
            case 12:{ int[] a=readArray(); System.out.println("Сумма = "+arraySum(a,0)); break; }
            case 13:{ int[] a=readArray(); if(a.length==0) throw new IllegalArgumentException("массив пуст"); System.out.println("Максимум = "+arrayMax(a,0)); break; }
            case 14:{ int[] a=readArray(); if(a.length==0) throw new IllegalArgumentException("массив пуст"); System.out.println("Минимум = "+arrayMin(a,0)); break; }
            case 15:{ int[] a=readArray(); System.out.println("Количество чётных = "+countEven(a,0)); break; }
            case 16:{ int[] a=readArray(); System.out.println(isIncreasing(a,0) ? "Массив отсортирован по возрастанию" : "Массив не отсортирован по возрастанию"); break; }
            case 17:{ System.out.print("a = "); int a=readInt(); System.out.print("b = "); int b=readInt(); System.out.println("НОД = "+gcd(a,b)); break; }
            case 18:{ System.out.print("a = "); long a=readInt(); System.out.print("b = "); long b=readInt(); System.out.println("НОК = "+lcm(a,b)); break; }
            case 19:{ System.out.print("Положительное число = "); int n=readInt(); if(n<=0) throw new IllegalArgumentException("число должно быть положительным"); System.out.println("Двоичная запись = "+toBinary(n)); break; }
            case 20:{ System.out.print("N = "); int n=readInt(); System.out.println("Сумма квадратов = "+sumSquares(n)); break; }
            case 21:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.println(reverse(s)); break; }
            case 22:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.println(isPalindrome(s,0,s.length()-1) ? "Палиндром" : "Не палиндром"); break; }
            case 23:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.print("Символ: "); char c=sc.nextLine().charAt(0); System.out.println("Количество = "+countChar(s,c,0)); break; }
            case 24:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.println("Количество гласных = "+countVowels(s,0)); break; }
            case 25:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.print("Удалить символ: "); char c=sc.nextLine().charAt(0); System.out.println(removeChar(s,c)); break; }
            case 26:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.print("Заменить символ: "); char a=sc.nextLine().charAt(0); System.out.print("На символ: "); char b=sc.nextLine().charAt(0); System.out.println(replaceChar(s,a,b)); break; }
            case 27:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.println(allSame(s,1) ? "Все символы одинаковые" : "Символы разные"); break; }
            case 28:{ sc.nextLine(); String s=readLinePrompt("Строка: "); System.out.println("Количество слов = "+countWords(s,0,false)); break; }
            case 29:{ sc.nextLine(); String a=readLinePrompt("Первая строка: ").replaceAll("\\s+","").toLowerCase(Locale.ROOT); String b=readLinePrompt("Вторая строка: ").replaceAll("\\s+","").toLowerCase(Locale.ROOT); System.out.println(isAnagram(a,b) ? "Анаграммы" : "Не анаграммы"); break; }
            case 30:{ sc.nextLine(); String a=readLinePrompt("Первая строка: "); String b=readLinePrompt("Вторая строка: "); int cmp=compareStrings(a,b,0); System.out.println(cmp==0 ? "Строки одинаковые" : cmp<0 ? "Первая строка меньше" : "Первая строка больше"); break; }
            case 31:{ System.out.print("a = "); long a=readInt(); System.out.print("n (>=0) = "); int n=readInt(); System.out.println("Результат = "+fastPower(a,n)); break; }
            case 32:{ int[] a=readArray(); Arrays.sort(a); System.out.println("Отсортированный массив: "+Arrays.toString(a)); System.out.print("Искомое число = "); int x=readInt(); System.out.println("Индекс = "+binarySearch(a,x,0,a.length-1)); break; }
            case 33:{ int[] a=readArray(); mergeSort(a,0,a.length-1); System.out.println(Arrays.toString(a)); break; }
            case 34:{ int[] a=readArray(); quickSort(a,0,a.length-1); System.out.println(Arrays.toString(a)); break; }
            case 35:{ System.out.print("Количество дисков (1..15) = "); int n=readInt(); if(n<1||n>15) throw new IllegalArgumentException("N должно быть от 1 до 15"); hanoi(n,"A","C","B"); break; }
            case 36:{ int[] a=readArray(); if(a.length>20) throw new IllegalArgumentException("для вывода всех подмножеств используйте до 20 элементов"); subsets(a,0,new ArrayList<>()); break; }
            case 37:{ sc.nextLine(); String s=readLinePrompt("Строка: "); permutations(s.toCharArray(),0); break; }
            case 38:{ mazeTask(); break; }
            case 39:{ System.out.print("N ферзей (1..12) = "); int n=readInt(); if(n<1||n>12) throw new IllegalArgumentException("N должно быть от 1 до 12"); queens(new int[n],0,n); break; }
            case 40:{ sc.nextLine(); String digits=readLinePrompt("Строка цифр: "); if(!digits.matches("\\d{1,9}")) throw new IllegalArgumentException("введите от 1 до 9 цифр"); System.out.print("Целевое число = "); long target=readInt(); expressionTask(digits,target); break; }
            default: System.out.println("Нужно выбрать номер от 1 до 40.");
        }
    }

    // 1-5: числа
    static void printUp(int n){ if(n<1)return; printUp(n-1); System.out.print(n+" "); }
    static void printDown(int n){ if(n<1)return; System.out.print(n+" "); printDown(n-1); }
    static long sumN(int n){ if(n<=0)return 0; return n+sumN(n-1); }
    static long factorial(int n){ return n<=1?1:n*factorial(n-1); }
    static long power(int a,int n){ if(n<0)throw new IllegalArgumentException("степень должна быть неотрицательной"); if(n==0)return 1; return (long)a*power(a,n-1); }

    // 6-10: цифры
    static int digitSum(int n){ if(n<10)return n; return n%10+digitSum(n/10); }
    static int digitCount(int n){ return n<10?1:1+digitCount(n/10); }
    static long digitProduct(int n){ if(n<10)return n; return (n%10)*digitProduct(n/10); }
    static int maxDigit(int n){ if(n<10)return n; return Math.max(n%10,maxDigit(n/10)); }
    static int minDigit(int n){ if(n<10)return n; return Math.min(n%10,minDigit(n/10)); }

    // 11-20: последовательности, массивы и числа
    static long fib(int n){ if(n<=1)return n; return fib(n-1)+fib(n-2); }
    static long arraySum(int[] a,int i){ return i==a.length?0:a[i]+arraySum(a,i+1); }
    static int arrayMax(int[] a,int i){ if(i==a.length-1)return a[i]; return Math.max(a[i],arrayMax(a,i+1)); }
    static int arrayMin(int[] a,int i){ if(i==a.length-1)return a[i]; return Math.min(a[i],arrayMin(a,i+1)); }
    static int countEven(int[] a,int i){ if(i==a.length)return 0; return (a[i]%2==0?1:0)+countEven(a,i+1); }
    static boolean isIncreasing(int[] a,int i){ if(i>=a.length-1)return true; return a[i]<=a[i+1] && isIncreasing(a,i+1); }
    static long gcd(long a,long b){ a=Math.abs(a); b=Math.abs(b); return b==0?a:gcd(b,a%b); }
    static long lcm(long a,long b){ if(a==0||b==0)return 0; return Math.abs((a/gcd(a,b))*b); }
    static String toBinary(int n){ if(n<2)return Integer.toString(n); return toBinary(n/2)+(n%2); }
    static long sumSquares(int n){ if(n<=0)return 0; return (long)n*n+sumSquares(n-1); }

    // 21-30: строки
    static String reverse(String s){ if(s.isEmpty())return s; return reverse(s.substring(1))+s.charAt(0); }
    static boolean isPalindrome(String s,int l,int r){ if(l>=r)return true; return s.charAt(l)==s.charAt(r)&&isPalindrome(s,l+1,r-1); }
    static int countChar(String s,char c,int i){ if(i==s.length())return 0; return (s.charAt(i)==c?1:0)+countChar(s,c,i+1); }
    static int countVowels(String s,int i){ if(i==s.length())return 0; char c=Character.toLowerCase(s.charAt(i)); String v="аеёиоуыэюяaeiou"; return (v.indexOf(c)>=0?1:0)+countVowels(s,i+1); }
    static String removeChar(String s,char c){ if(s.isEmpty())return s; return (s.charAt(0)==c?"":s.substring(0,1))+removeChar(s.substring(1),c); }
    static String replaceChar(String s,char a,char b){ if(s.isEmpty())return s; return (s.charAt(0)==a?b:s.charAt(0))+replaceChar(s.substring(1),a,b); }
    static boolean allSame(String s,int i){ if(s.length()<=1||i>=s.length())return true; return s.charAt(i)==s.charAt(0)&&allSame(s,i+1); }
    static int countWords(String s,int i,boolean inWord){ if(i==s.length())return inWord?1:0; boolean now=!Character.isWhitespace(s.charAt(i)); return (inWord&&!now?1:0)+countWords(s,i+1,now); }
    static boolean isAnagram(String a,String b){ if(a.length()!=b.length())return false; int[] freq=new int[Character.MAX_VALUE+1]; fillFreq(a,0,freq,1); fillFreq(b,0,freq,-1); return anagramCheck(a,0,freq); }
    static void fillFreq(String s,int i,int[] f,int delta){ if(i==s.length())return; f[s.charAt(i)]+=delta; fillFreq(s,i+1,f,delta); }
    static boolean anagramCheck(String s,int i,int[] f){ if(i==s.length())return true; return f[s.charAt(i)]==0&&anagramCheck(s,i+1,f); }
    static int compareStrings(String a,String b,int i){ if(i==a.length()||i==b.length())return Integer.compare(a.length(),b.length()); if(a.charAt(i)!=b.charAt(i))return Character.compare(a.charAt(i),b.charAt(i)); return compareStrings(a,b,i+1); }

    // 31-40: алгоритмы и backtracking
    static long fastPower(long a,int n){ if(n<0)throw new IllegalArgumentException("степень должна быть неотрицательной"); if(n==0)return 1; long half=fastPower(a,n/2); return n%2==0?half*half:half*half*a; }
    static int binarySearch(int[] a,int x,int l,int r){ if(l>r)return -1; int m=l+(r-l)/2; if(a[m]==x)return m; return a[m]>x?binarySearch(a,x,l,m-1):binarySearch(a,x,m+1,r); }
    static void mergeSort(int[] a,int l,int r){ if(l>=r)return; int m=(l+r)/2; mergeSort(a,l,m); mergeSort(a,m+1,r); merge(a,l,m,r); }
    static void merge(int[] a,int l,int m,int r){ int[] tmp=new int[r-l+1]; int i=l,j=m+1,k=0; while(i<=m&&j<=r)tmp[k++]=a[i]<=a[j]?a[i++]:a[j++]; while(i<=m)tmp[k++]=a[i++]; while(j<=r)tmp[k++]=a[j++]; System.arraycopy(tmp,0,a,l,tmp.length); }
    static void quickSort(int[] a,int l,int r){ if(l>=r)return; int i=l,j=r,p=a[l+(r-l)/2]; while(i<=j){ while(a[i]<p)i++; while(a[j]>p)j--; if(i<=j){int t=a[i];a[i]=a[j];a[j]=t;i++;j--;}} if(l<j)quickSort(a,l,j); if(i<r)quickSort(a,i,r); }
    static void hanoi(int n,String from,String to,String aux){ if(n==0)return; hanoi(n-1,from,aux,to); System.out.println(from+" -> "+to); hanoi(n-1,aux,to,from); }
    static void subsets(int[] a,int i,List<Integer> chosen){ if(i==a.length){System.out.println(chosen);return;} subsets(a,i+1,chosen); chosen.add(a[i]); subsets(a,i+1,chosen); chosen.remove(chosen.size()-1); }
    static void permutations(char[] a,int i){ if(i==a.length){System.out.println(new String(a));return;} Set<Character> used=new HashSet<>(); for(int j=i;j<a.length;j++){ if(!used.add(a[j]))continue; char t=a[i];a[i]=a[j];a[j]=t; permutations(a,i+1); t=a[i];a[i]=a[j];a[j]=t; } }

    static void mazeTask(){
        System.out.print("Строки и столбцы лабиринта: "); int rows=readInt(), cols=readInt();
        if(rows<1||cols<1||rows>30||cols>30)throw new IllegalArgumentException("размеры от 1 до 30");
        int[][] maze=new int[rows][cols];
        System.out.println("Введите матрицу (0 — проход, 1 — стена):");
        for(int r=0;r<rows;r++)for(int c=0;c<cols;c++)maze[r][c]=readInt();
        System.out.print("Старт (строка столбец, с 0): "); int sr=readInt(),sc0=readInt();
        System.out.print("Финиш (строка столбец, с 0): "); int er=readInt(),ec=readInt();
        if(!inside(sr,sc0,rows,cols)||!inside(er,ec,rows,cols))throw new IllegalArgumentException("координаты вне лабиринта");
        boolean[][] seen=new boolean[rows][cols]; List<String> path=new ArrayList<>();
        if(findPath(maze,sr,sc0,er,ec,seen,path))System.out.println("Путь: "+path); else System.out.println("Путь не найден.");
    }
    static boolean inside(int r,int c,int R,int C){return r>=0&&r<R&&c>=0&&c<C;}
    static boolean findPath(int[][] m,int r,int c,int er,int ec,boolean[][] seen,List<String> path){
        if(!inside(r,c,m.length,m[0].length)||m[r][c]!=0||seen[r][c])return false;
        seen[r][c]=true; path.add("("+r+","+c+")");
        if(r==er&&c==ec)return true;
        if(findPath(m,r+1,c,er,ec,seen,path)||findPath(m,r,c+1,er,ec,seen,path)||findPath(m,r-1,c,er,ec,seen,path)||findPath(m,r,c-1,er,ec,seen,path))return true;
        path.remove(path.size()-1); return false;
    }
    static void queens(int[] pos,int row,int n){
        if(row==n){ for(int r=0;r<n;r++){for(int c=0;c<n;c++)System.out.print(pos[r]==c?"Q ":"· ");System.out.println();}System.out.println();return;}
        for(int c=0;c<n;c++){if(safeQueen(pos,row,c)){pos[row]=c;queens(pos,row+1,n);}}
    }
    static boolean safeQueen(int[] pos,int row,int col){ if(row==0)return true; for(int r=0;r<row;r++)if(pos[r]==col||Math.abs(pos[r]-col)==Math.abs(r-row))return false;return true;}

    static void expressionTask(String digits,long target){ expressionSearch(digits,1,digits.substring(0,1),Long.parseLong(digits.substring(0,1)),Long.parseLong(digits.substring(0,1)),target); }
    static void expressionSearch(String digits,int index,String expr,long value,long last,long target){
        if(index==digits.length()){if(value==target)System.out.println(expr+" = "+target);return;}
        for(int end=index+1;end<=digits.length();end++){
            String part=digits.substring(index,end);
            if(part.length()>1&&part.charAt(0)=='0')break;
            long x=Long.parseLong(part);
            expressionSearch(digits,end,expr+"+"+part,value+x,x,target);
            expressionSearch(digits,end,expr+"-"+part,value-x,-x,target);
            // Multiplication adjusts the previous term to preserve normal operator precedence.
            expressionSearch(digits,end,expr+"*"+part,value-last+last*x,last*x,target);
        }
    }
}
