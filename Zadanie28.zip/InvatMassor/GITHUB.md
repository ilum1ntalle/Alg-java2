# Как загрузить проект на GitHub

1. Создайте аккаунт на https://github.com/ и войдите в него.
2. На GitHub нажмите **New repository**.
3. Назовите репозиторий `recursion-java-tasks`, выберите Public или Private и создайте репозиторий.
4. В VS Code откройте папку проекта.
5. Откройте терминал (**Terminal → New Terminal**) и выполните команды ниже, заменив `YOUR-USERNAME` на свой логин GitHub:

```bash
git init
git add .
git commit -m "Add 40 recursive Java tasks"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/recursion-java-tasks.git
git push -u origin main
```

Если Git попросит настроить имя и почту, выполните:

```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

Затем повторите `git commit` и `git push`. Для отправки через HTTPS GitHub может попросить авторизацию в браузере.
